## Что такое?
### Habr
ссылка: https://habr.com/ru/companies/otus/articles/873118/
Что такое signals.py: это встроенный механизм, который позволяет общаться между разными частями приложения через события.

Для чего они нужны:
- Реакция на определённые события
- Изоляция логики обработки событий
- Не вмешиваться в другие приложения, но понимать, что там происходит

Схема: Отправитель-->Сигнал-->Обработчики
- Отправитель: генерация события
- Сигнал: уведомляет зарегистрированные обработчики
- Обработчики: реагирует на сигнал и выполняет логику

Полезны:
- Разделение логики. Уведомление, фоновые задачи, обработка сигналов
- Модульность. Добавление без изменения основного кода.
- Многоуровневая обработка. Действие запускает несколько независимых действий
Вредны:
- Прямая зависимость. Если обработчик используется в одном месте, то лучше вызывать функцию напрямую
- Сложная бизнес-логика. Плохо будет писать сложную логику в сигналах.

Встроенные сигналы:
- pre_save и post_save: вызов сигнала до и после сохранения объекта
- pre_delete и post_delete: то же самое, но с удалением объекта
- pre_request и post_request: в начале и конце запроса
- user_logged_in и user_logged_out: пользователь вошёл/вышел

Как подключить:
- Метод connect
```
from django.db.models.signals import post_save
from myapp.models import MyModeldef 

my_handler(sender, **kwargs):    
	print("Объект сохранён!")

post_save.connect(my_handler, sender=MyModel) <-- тут вызывается обработчик
```
- Декоратор @receive
```
from django.db.models.signals import post_save
from django.dispatch import receiver
from myapp.models import MyModel

@receiver(post_save, sender=MyModel) <-- тут вызывается обработчик
def my_handler(sender, **kwargs):    
	print("Объект сохранён!")
```


### Django Docs
ссылка: https://django.fun/docs/django/5.2/topics/signals/

Сигналы - это способ уведомлять разделённые части приложения о происходящих событиях, чтобы они могли совершить некое действие на это событие. 
_Отправители_ уведомляют _получателей_ о произошедшем действии, и _получатели_ выполняют свои действия.

	Возможные проблемы: сигналы могут приводить к трудночитаемому коду, поэтому их
	надо использовать по необходимости, желательно прямо вызывать код обработки

Приложение может __зарегистрироваться__ для получения уведомлений через метод Signal.connect:
```
from django.apps import AppConfig
from django.core.signals import setting_changed

def my_callback(sender, **kwargs):
    print("Setting changed!")

class MyAppConfig(AppConfig):
    ...

    def ready(self):
        setting_changed.connect(my_callback)
```

__Signal.connect(receiver, sender=None, weak=True, dispatch_uid=None)__.
- receiver: функция обратного вызова, подключённая к сигналу (приёмник)
- sender: отправитель сигнала
- weak: обработчик помечается как _слабая ссылка_. (слабая сслыка не препятствует сборщику мусора, если на неё нет сильной ссылки)
- dispatch_uid: уникальный ИД для приёмника сигнала

Приёмником может быть любая функция в Питоне, с аргументами sender и ** kwargs (обязательны). Могут быть асинхронными (async def)
```
async def my_callback(sender, **kwargs):
    await asyncio.sleep(5)
    print("Request finished!")
```

Подключение приёмника к сигналу: как на хабре
Приемники подключаются через метод ready()


## Сигналы в проекте
	Отключены в файлах тестирования приложений

### Запись предыдущего статуса геймджема

```
@receiver(post_init, sender=GameJam)
def post_init_previous_jam_status_handler(sender, instance, **kwargs):
    """ Сигнал записывающий предыдущий статус геймджема (исползуется в других сигналах) """
    instance.previous_status = instance.status
```

post_init: вызвать сигнал после инициализации объекта модели GameJam (то есть после запуска метода ```__init__``` в классе модели)

Принимает аргумент instance, которому устанавливает предыдущий статус геймджема. Данный сигнал используется в других сигналах

### Выбор победителя

```
@receiver(pre_save, sender=GameJam)
def calculate_winner_when_jam_finished(sender, instance, **kwargs):
    """ Сигнал вычисляющий победителя при завершении геймджема """
    if instance.previous_status != 'FN' and instance.status == 'FN':
        instance.previous_status = 'FN'

        final_rating = count_jam_rating(instance.uuid).order_by('-avg_rating')

        if final_rating.exists():
            winner_id = final_rating.first()['user__id']

            winner_user = get_user_model().objects.filter(id=winner_id)

            if winner_user.exists():
                instance.winner = winner_user[0]
                instance.save()
```

Вызывается перед сохранением объекта.

Устанавливается тема завершения джема.

Подсчитывается финальный рейтинг и сортируется по результату.

Выбирается первый из этого списка и ему устанавливается в джеме как победитель.

### Установка финальной темы

```
@receiver(pre_save, sender=GameJam)
def set_final_theme_when_jam_prepared(sender, instance, **kwargs):
    """ Сигнал устанавливающий тему окончания подготовки джема """
    if instance.previous_status == 'PR' and instance.status == 'OG':
        instance.previous_status = 'OG'

        jam_polls = GameJamTheme.objects.filter(gamejam=instance)

        themes_with_difference = jam_polls.annotate(
            true_votes=Count('themevote', filter=Q(themevote__vote=True)),
            false_votes=Count('themevote', filter=Q(themevote__vote=False)),
            difference=Count('themevote', filter=Q(themevote__vote=True)) - Count('themevote', filter=Q(themevote__vote=False))
        )

        theme_with_max_difference = themes_with_difference.order_by('-difference').first()

        if theme_with_max_difference:
            instance.theme = theme_with_max_difference.theme
        else:
            instance.theme = None
```

Вызывается перед сохранением объекта.

Происходит установка нового состояния джема.

Идёт поиск всех джемов, которые равны instance.

Создаётся новая переменная themes_with_difference, в которое записываются объекты фильтра jam_polls с добавлением новых полей: true_votes, false_votes, difference.

Создаётся переменная с максимальным значением difference.

Если такая тема находится, то она устанавливается, иначе нет.

### Установка 3х случайных тем в голосовании 

```
#Проблемы когда тем в базе нет, то возникает ошибка
@receiver(pre_save, sender=GameJam)
def set_random_themes_for_jam_when_it_created(sender, instance, **kwargs):
    """ Сигнал выбирающий 3-и случайные темы на голосование при создании геймджема """
    if instance.status == 'PR' and not GameJamTheme.objects.filter(gamejam=instance).exists():
        themes_max_pk = Theme.objects.all().aggregate(Max('pk'))['pk__max']

        random_picked_themes = Theme.objects.filter(pk__in=random.sample(range(1, themes_max_pk + 1), 3))
        GameJamTheme.objects.bulk_create([GameJamTheme(gamejam=instance, theme=theme) for theme in random_picked_themes])
```

Вызывается перед сохранением объекта.

Если тем у геймджема нет, то берётся три случайных темы из общего сборника.

Берётся макс. число тем, выбирается три случайных тем от 1 до макс. числа и создаёт их в GameJamTheme методом bulk_create