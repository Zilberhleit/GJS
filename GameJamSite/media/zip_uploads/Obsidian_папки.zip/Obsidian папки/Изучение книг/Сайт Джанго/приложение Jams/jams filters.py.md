```
class GameJamsFilter(django_filters.FilterSet):
    """  Фильтры для джемов   """
    title = django_filters.CharFilter(field_name='title', lookup_expr='icontains', label='Название джема')

    date_start = django_filters.DateFilter(field_name='date_start', label='Дата начала джема', lookup_expr='gte')
    date_end = django_filters.DateFilter(field_name='date_end', label='Дата окончания джема', lookup_expr='lte')

    status = django_filters.ChoiceFilter(field_name='status', lookup_expr='exact', choices=GameJam.jam_status)

    class Meta:
        model = GameJam
        fields = ['title', 'date_start', 'date_end', 'status']
```

Класс для фильтрации джема со стороны пользователя. 

Выбирает названия, начало, конец и статус джемов.