Ссылка: https://www.youtube.com/watch?v=whzomFgjT50
Top Down движение - это движение как в старых РПГ. Оно выглядит примерно как в играх серии Final Fantasy 1-6, Dragon Quest, The Legend Of Zelda и другие игры.

## Теория
Основа Top-Down движения является движение в 2D пространстве, а именно когда спрайт движется на плоскости, а игрок смотрит на него сверху (например, настольные игры). 

Игрок не может двигаться по диагонали. Игрок движется "по клеткам", то есть он движется с определённой скоростью останавливается только в определённых точках.
## Код
### Заметка №1
```
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float walkSpeed = 5f, // Скорость
        gridSize = 1f; // Размер клетки

    public LayerMask obstacleLayer; // Слой, который останавливает игрока как препятствие 

    public Rigidbody2D rb;

    private InputAction moveAction;

    private Vector3 gridTargetPos; // Целевая позиция на сетке

    private Vector2 moveInput, 
        inputDir; // Направление ввода игрока
    
    private void Awake() // Ввод с клавиатуры
    {
        moveAction = new InputAction("Move", binding: "<Keyboard>/wasd");
        moveAction.AddCompositeBinding("2DVector")
            .With("Up", "Keyboard/w")
            .With("Down", "Keyboard/s")
            .With("Left", "Keyboard/a")
            .With("Right", "Keyboard/d");

        rb = GetComponent<Rigidbody2D>();

        moveAction.Enable();
    }

    void Update() // Счёт ввода
    {
        moveInput = moveAction.ReadValue<Vector2>();
        GetInput();
    }

    private void FixedUpdate() // Вызов функции движения
    {
        Move();
    }

    private void Move() // Функция движения
    {
	    // Создание новой позиции игрока
        Vector3 newPos = Vector3.MoveTowards( // Функция перемещения с одной точки на другую
            transform.position, // - Изначальная точка
            gridTargetPos, // - Конечная точка
            walkSpeed * Time.fixedDeltaTime); // - Ограничение скорости

        rb.MovePosition(newPos); // Перемещение RigidBody на вычисленную точку

        if (Vector3.Distance(transform.position, gridTargetPos) < 0.01f) // Условие: Если дистанция между игроком и позицией сетки меньше значения 0.01, то позицию игрока ставят на позицию сетки
        {
            transform.position = gridTargetPos;
        }
    }

    void GetInput() // Обработка ввода как в ретро-играх
    {
        inputDir = new Vector2(moveInput.x, moveInput.y); // Вектор направления

        if (Mathf.Abs(inputDir.x) > Mathf.Abs(inputDir.y)) // Условие движения без диагонали
            inputDir.y = 0;
        else inputDir.x = 0;

        if (inputDir != Vector2.zero && CanMove(inputDir)) // Проверка на препятсвие
        {
            gridTargetPos = transform.position + new Vector3(
                inputDir.x * gridSize,
                inputDir.y * gridSize,
                0);
        }
    }

    bool CanMove(Vector2 direction) // Проверка возможности движения
    {
        RaycastHit2D hit = Physics2D.BoxCast(
            transform.position,
            new Vector2(0.8f, 0.8f),
            0f,
            direction,
            gridSize,
            obstacleLayer);

        return hit.collider == null;
    }
}
```
### Заметка №2
```
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float walkSpeed = 5f,
        gridSize = 1f;

    public LayerMask obstacleLayer;

    public Rigidbody2D rb;

    private InputAction moveAction;

    private bool isMoving = false,
        hasBufferedInput = false;

    private Vector3 gridTargetPos;

    private Vector2 moveInput,
        inputDir;
    
    private void Awake()
    {
        moveAction = new InputAction("Move", binding: "<Keyboard>/wasd");
        moveAction.AddCompositeBinding("2DVector")
            .With("Up", "Keyboard/w")
            .With("Down", "Keyboard/s")
            .With("Left", "Keyboard/a")
            .With("Right", "Keyboard/d");

        rb = GetComponent<Rigidbody2D>();

        moveAction.Enable();
    }

    void Update()
    {
        moveInput = moveAction.ReadValue<Vector2>();
        GetInput();
    }

    private void FixedUpdate()
    {
        Move();
    }

    private void Move()
    {
        if (!isMoving) return;

        Vector3 newPos = Vector3.MoveTowards(
            transform.position,
            gridTargetPos,
            walkSpeed * Time.fixedDeltaTime);

        rb.MovePosition(newPos);

        if (Vector3.Distance(transform.position, gridTargetPos) < 0.01f)
        {
            transform.position = gridTargetPos;
            isMoving = false;
        }
    }

    void GetInput()
    {

        if (isMoving) return;

        inputDir = new Vector2(moveInput.x, moveInput.y);

        if (Mathf.Abs(inputDir.x) > Mathf.Abs(inputDir.y))
            inputDir.y = 0;
        else inputDir.x = 0;

        if (inputDir != Vector2.zero && CanMove(inputDir))
        {
            gridTargetPos = transform.position + new Vector3(
                inputDir.x * gridSize,
                inputDir.y * gridSize,
                0);
            gridTargetPos = new Vector3(RoundGrid(gridTargetPos.x),
                RoundGrid(gridTargetPos.y),
                0);
            isMoving = true;
        }
    }
	// Округление значения, предназначена для того, чтобы игрок ходил строго в одинаковое расстояние КАК "в клетках", предназначен строго по клеткам в юнити
    float RoundGrid(float inputVal)
    {
        float result = Mathf.Round(inputVal / 0.5f) * 0.5f;

        if (result == Mathf.Floor(result)) result += 0.5f * Mathf.Sign(inputVal);

        return result;
    }

    bool CanMove(Vector2 direction)
    {
        RaycastHit2D hit = Physics2D.BoxCast(
            transform.position,
            new Vector2(0.8f, 0.8f),
            0f,
            direction,
            gridSize,
            obstacleLayer);

        return hit.collider == null;
    }
}

```
### Заметка №3
```
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float walkSpeed = 5f,
        gridSize = 1f;

    public LayerMask obstacleLayer;

    public Rigidbody2D rb;

    private InputAction moveAction;

    private bool isMoving = false;

    private Vector3 gridTargetPos;

    private Vector2 moveInput,
        inputDir, lastNonZeroInputDir;
    
    private void Awake()
    {
        moveAction = new InputAction("Move", binding: "<Keyboard>/wasd");
        moveAction.AddCompositeBinding("2DVector")
            .With("Up", "Keyboard/w")
            .With("Down", "Keyboard/s")
            .With("Left", "Keyboard/a")
            .With("Right", "Keyboard/d");

        rb = GetComponent<Rigidbody2D>();

        moveAction.Enable();
    }

    void Update()
    {
        moveInput = moveAction.ReadValue<Vector2>();
        GetInput();
    }

    private void FixedUpdate()
    {
        Move();
    }

    #region Moving
    private void Move()
    {
        if (!isMoving) return;

        Vector3 newPos = Vector3.MoveTowards(
            transform.position,
            gridTargetPos,
            walkSpeed * Time.fixedDeltaTime);

        rb.MovePosition(newPos);

        if (Vector3.Distance(transform.position, gridTargetPos) < 0.01f)
        {
            transform.position = gridTargetPos;
            isMoving = false;
        }
    }

    void GetInput()
    {
        if (isMoving) return;

        inputDir = new Vector2(moveInput.x, moveInput.y);

        if (Mathf.Abs(inputDir.x) > Mathf.Abs(inputDir.y))
            inputDir.y = 0;
        else inputDir.x = 0;

        if (inputDir != Vector2.zero && CanMove(inputDir))
        {
            gridTargetPos = transform.position + new Vector3(
                inputDir.x * gridSize,
                inputDir.y * gridSize,
                0);
            gridTargetPos = new Vector3(RoundGrid(gridTargetPos.x),
                RoundGrid(gridTargetPos.y),
                0);
            isMoving = true;
        }

        if (inputDir.magnitude > 0.1f) 
        {
            lastNonZeroInputDir = inputDir.normalized;
        }
    }

    float RoundGrid(float inputVal)
    {
        float result = Mathf.Round(inputVal / 0.5f) * 0.5f;

        if (result == Mathf.Floor(result)) result += 0.5f * Mathf.Sign(inputVal);

        return result;
    }

    bool CanMove(Vector2 direction)
    {
        RaycastHit2D hit = CheckRayHitLayer(direction, obstacleLayer);
        return hit.collider == null;
    }
    #endregion

    RaycastHit2D CheckRayHitLayer(Vector2 direction, LayerMask layer)
    {
        RaycastHit2D hit = Physics2D.BoxCast(
            transform.position,
            new Vector2(0.8f, 0.8f),
            0f,
            direction,
            gridSize * 0.9f,
            layer);

        return hit;
    }

    #region TagInteract
    private float distance, pickupDistance = 1.5f;
	// Взаимодействие с предметами-тегами
    public bool TagInteract(Vector2 direction, string tag, Transform objectTransform)
    {
        RaycastHit2D hit = CheckRayHitLayer(direction, obstacleLayer);

        distance = Vector2.Distance(objectTransform.position, transform.position);

        if (distance <= pickupDistance)
        {
            if (hit.collider != null)
            {
                if (hit.collider.gameObject.CompareTag(tag))
                    return true;
            }
        }
        return false;
    }
	// Получение направления игрока, т.к. InputDir обнуляется при остановке игрока
    public Vector2 GetNonZeroInputDir()
    {
        return lastNonZeroInputDir;
    }

    public void SetInputDir(Vector2 newInputDir)
    {
        inputDir = newInputDir;
        lastNonZeroInputDir = newInputDir;
    }
	// Установка нового направление игрока без цикл. зависимости при перемещении через дверь
    private void OnEnable()
    {
        DoorTeleport.OnTeleportCompleted += HandleTeleport;
    }

    private void OnDisable()
    {
        DoorTeleport.OnTeleportCompleted -= HandleTeleport;
    }

    private void HandleTeleport(Vector2 newDir)
    {
        SetInputDir(newDir);
    }
    #endregion
}

```