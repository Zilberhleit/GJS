from django.contrib import admin
from jam_polls.models import Question

admin.site.register(Question)
